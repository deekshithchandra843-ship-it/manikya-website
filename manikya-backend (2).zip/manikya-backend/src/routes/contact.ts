import { Router, Request, Response } from 'express';
import { query } from '../db/pool';
import { requireAdmin, AuthRequest } from '../middleware/auth';

const router = Router();

// ── POST /api/contact  (public) ───────────────────────────────
router.post('/', async (req: Request, res: Response) => {
  const { name, email, phone, interest, message } = req.body;

  if (!name || !message || (!email && !phone)) {
    res.status(400).json({ error: 'name, message, and email or phone are required' });
    return;
  }

  try {
    const rows = await query<{ id: string }>(
      `INSERT INTO contact_leads (name, email, phone, interest, message, ip_address)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id`,
      [name, email || null, phone || null, interest || null, message, req.ip]
    );
    res.status(201).json({ message: 'Thank you! We will get in touch soon.', id: rows[0].id });
  } catch (err) {
    console.error('contact insert error:', err);
    res.status(500).json({ error: 'Failed to save your message. Please try again.' });
  }
});

// ── GET /api/contact (admin) ──────────────────────────────────
router.get('/', requireAdmin, async (_req: AuthRequest, res: Response) => {
  const rows = await query(
    `SELECT id, name, email, phone, interest, message, status, ip_address, created_at
     FROM contact_leads
     ORDER BY created_at DESC`
  );
  res.json(rows);
});

// ── PATCH /api/contact/:id/status (admin) ────────────────────
router.patch('/:id/status', requireAdmin, async (req: AuthRequest, res: Response) => {
  const { status } = req.body;
  const validStatuses = ['new', 'contacted', 'closed'];
  if (!validStatuses.includes(status)) {
    res.status(400).json({ error: `status must be one of: ${validStatuses.join(', ')}` });
    return;
  }
  await query(
    `UPDATE contact_leads SET status = $1 WHERE id = $2`,
    [status, req.params.id]
  );
  res.json({ message: 'Status updated' });
});

// ── DELETE /api/contact/:id (admin) ──────────────────────────
router.delete('/:id', requireAdmin, async (req: AuthRequest, res: Response) => {
  await query(`DELETE FROM contact_leads WHERE id = $1`, [req.params.id]);
  res.json({ message: 'Lead deleted' });
});

export default router;
