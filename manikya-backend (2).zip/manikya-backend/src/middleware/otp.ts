import crypto from 'crypto';
import nodemailer from 'nodemailer';
import { query } from '../db/pool';

// ── Generate a 6-digit OTP ────────────────────────────────────
export function generateOTP(): string {
  return String(crypto.randomInt(100000, 999999));
}

// ── Generate a secure magic-link token ───────────────────────
export function generateMagicToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// ── Save token to DB ─────────────────────────────────────────
export async function saveOTP(
  identifier: string,
  method: 'email' | 'phone',
  type: 'otp' | 'magic_link',
  token: string
): Promise<void> {
  const expiresMin = Number(process.env.OTP_EXPIRES_MINUTES) || 10;
  await query(
    `INSERT INTO otp_tokens (identifier, method, type, token, expires_at)
     VALUES ($1, $2, $3, $4, NOW() + $5::interval)`,
    [identifier, method, type, token, `${expiresMin} minutes`]
  );
}

// ── Verify OTP from DB ────────────────────────────────────────
export async function verifyOTPToken(
  identifier: string,
  token: string
): Promise<boolean> {
  const rows = await query<{ id: string }>(
    `SELECT id FROM otp_tokens
     WHERE identifier = $1
       AND token      = $2
       AND used       = FALSE
       AND expires_at > NOW()
     LIMIT 1`,
    [identifier, token]
  );
  if (rows.length === 0) return false;
  // Mark as used
  await query(`UPDATE otp_tokens SET used = TRUE WHERE id = $1`, [rows[0].id]);
  return true;
}

// ── Nodemailer transporter ────────────────────────────────────
function getTransporter() {
  return nodemailer.createTransport({
    host:   process.env.SMTP_HOST || 'smtp.gmail.com',
    port:   Number(process.env.SMTP_PORT) || 587,
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });
}

// ── Send OTP email ────────────────────────────────────────────
export async function sendOTPEmail(email: string, otp: string): Promise<void> {
  const transporter = getTransporter();
  await transporter.sendMail({
    from:    process.env.EMAIL_FROM || 'Manikya Services <no-reply@manikya.com>',
    to:      email,
    subject: `Your Manikya verification code: ${otp}`,
    html: `
      <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:32px;border:1px solid #e2e8f0;border-radius:8px">
        <h2 style="color:#1a3a5c;margin-bottom:8px">Manikya Services</h2>
        <p style="color:#475569">Your one-time verification code is:</p>
        <div style="font-size:36px;font-weight:700;letter-spacing:12px;color:#0f172a;margin:24px 0">${otp}</div>
        <p style="color:#64748b;font-size:14px">This code expires in ${process.env.OTP_EXPIRES_MINUTES || 10} minutes.<br>Do not share it with anyone.</p>
      </div>
    `,
  });
}

// ── Send magic-link email ─────────────────────────────────────
export async function sendMagicLinkEmail(email: string, token: string): Promise<void> {
  const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173';
  const link = `${frontendUrl}/auth/verify-otp?magic=${token}&email=${encodeURIComponent(email)}`;
  const transporter = getTransporter();
  await transporter.sendMail({
    from:    process.env.EMAIL_FROM || 'Manikya Services <no-reply@manikya.com>',
    to:      email,
    subject: 'Sign in to Manikya Services',
    html: `
      <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:32px;border:1px solid #e2e8f0;border-radius:8px">
        <h2 style="color:#1a3a5c;margin-bottom:8px">Manikya Services</h2>
        <p style="color:#475569">Click the button below to sign in. This link expires in ${process.env.OTP_EXPIRES_MINUTES || 10} minutes.</p>
        <a href="${link}" style="display:inline-block;margin:24px 0;padding:14px 28px;background:#1a3a5c;color:#fff;text-decoration:none;border-radius:6px;font-weight:600">Sign In to Manikya</a>
        <p style="color:#94a3b8;font-size:12px">If you didn't request this, you can ignore this email.</p>
      </div>
    `,
  });
}

// ── Send OTP via SMS (Twilio) ─────────────────────────────────
export async function sendOTPSMS(phone: string, otp: string): Promise<void> {
  // Install twilio: npm install twilio @types/twilio
  // Uncomment below when Twilio credentials are added:
  //
  // const twilio = require('twilio')(
  //   process.env.TWILIO_ACCOUNT_SID,
  //   process.env.TWILIO_AUTH_TOKEN
  // );
  // await twilio.messages.create({
  //   body: `Your Manikya verification code: ${otp}. Valid for ${process.env.OTP_EXPIRES_MINUTES || 10} minutes.`,
  //   from: process.env.TWILIO_PHONE_NUMBER,
  //   to:   phone,
  // });

  // Placeholder — logs to console until Twilio is configured
  console.log(`[SMS] → ${phone}: OTP ${otp}`);
}
