import { useState, useEffect, useRef, useCallback } from 'react';
import { Link } from 'react-router';
import {
  ArrowRight, Sparkles, TrendingUp, Users, ShoppingBag, Newspaper,
  Leaf, Landmark, Phone, Mail, MapPin, Star, ChevronRight,
  Award, Shield, Play, Zap
} from 'lucide-react';

/* ─────────────────────────────────────────────
   CANVAS STAR-FIELD
───────────────────────────────────────────── */
function StarField() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    let animId: number;
    const resize = () => { canvas.width = canvas.offsetWidth; canvas.height = canvas.offsetHeight; };
    resize();
    window.addEventListener('resize', resize);
    const stars = Array.from({ length: 160 }, () => ({
      x: Math.random() * canvas.width, y: Math.random() * canvas.height,
      r: Math.random() * 1.5 + 0.3, speed: Math.random() * 0.3 + 0.05,
      opacity: Math.random(), pulse: Math.random() * Math.PI * 2,
    }));
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      stars.forEach(s => {
        s.pulse += 0.02; s.opacity = 0.3 + Math.sin(s.pulse) * 0.3;
        s.y += s.speed; if (s.y > canvas.height) { s.y = 0; s.x = Math.random() * canvas.width; }
        ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255,255,255,${s.opacity})`; ctx.fill();
      });
      animId = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(animId); window.removeEventListener('resize', resize); };
  }, []);
  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" style={{ opacity: 0.6 }} />;
}

/* ─────────────────────────────────────────────
   CANVAS AURORA
───────────────────────────────────────────── */
function Aurora() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    let animId: number; let t = 0;
    const resize = () => { canvas.width = canvas.offsetWidth; canvas.height = canvas.offsetHeight; };
    resize(); window.addEventListener('resize', resize);
    const bands = [
      { y: 0.3, c1: 'rgba(59,130,246,0.12)', c2: 'rgba(16,185,129,0.06)', amp: 60, freq: 0.8 },
      { y: 0.5, c1: 'rgba(139,92,246,0.08)', c2: 'rgba(59,130,246,0.12)', amp: 80, freq: 0.6 },
      { y: 0.7, c1: 'rgba(245,158,11,0.06)', c2: 'rgba(59,130,246,0.08)', amp: 50, freq: 1.0 },
    ];
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height); t += 0.004;
      bands.forEach(b => {
        const baseY = canvas.height * b.y;
        ctx.beginPath(); ctx.moveTo(0, baseY);
        for (let x = 0; x <= canvas.width; x += 4) {
          const y = baseY + Math.sin(x * 0.003 * b.freq + t) * b.amp + Math.sin(x * 0.007 + t * 1.3) * b.amp * 0.4;
          ctx.lineTo(x, y);
        }
        ctx.lineTo(canvas.width, canvas.height); ctx.lineTo(0, canvas.height); ctx.closePath();
        const grad = ctx.createLinearGradient(0, baseY - b.amp, 0, baseY + b.amp);
        grad.addColorStop(0, b.c1); grad.addColorStop(1, b.c2);
        ctx.fillStyle = grad; ctx.fill();
      });
      animId = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(animId); window.removeEventListener('resize', resize); };
  }, []);
  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />;
}

/* ─────────────────────────────────────────────
   GLOW ORBS
───────────────────────────────────────────── */
function GlowOrbs() {
  const orbs = [
    { size: 320, x: '70%', y: '15%', color: 'radial-gradient(circle,rgba(59,130,246,0.28),transparent)', delay: 0 },
    { size: 220, x: '10%', y: '60%', color: 'radial-gradient(circle,rgba(245,158,11,0.18),transparent)', delay: 2 },
    { size: 260, x: '85%', y: '72%', color: 'radial-gradient(circle,rgba(16,185,129,0.18),transparent)', delay: 4 },
    { size: 180, x: '42%', y: '80%', color: 'radial-gradient(circle,rgba(139,92,246,0.18),transparent)', delay: 1 },
  ];
  return (
    <>
      {orbs.map((o, i) => (
        <div key={i} className="absolute pointer-events-none" style={{
          width: o.size, height: o.size, left: o.x, top: o.y, borderRadius: '50%',
          background: o.color, transform: 'translate(-50%,-50%)',
          animation: `floatOrb ${6 + o.delay}s ease-in-out ${o.delay}s infinite alternate`,
        }} />
      ))}
    </>
  );
}

/* ─────────────────────────────────────────────
   GRID LINES
───────────────────────────────────────────── */
function GridLines() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden" style={{ opacity: 0.04 }}>
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: 'linear-gradient(rgba(255,255,255,0.8) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.8) 1px,transparent 1px)',
        backgroundSize: '60px 60px', animation: 'gridMove 20s linear infinite',
      }} />
    </div>
  );
}

/* ─────────────────────────────────────────────
   HOOKS
───────────────────────────────────────────── */
function useInView(threshold = 0.12) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setInView(true); obs.disconnect(); } }, { threshold });
    obs.observe(el); return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

function Counter({ end, suffix = '', duration = 2000 }: { end: number; suffix?: string; duration?: number }) {
  const [count, setCount] = useState(0);
  const { ref, inView } = useInView();
  useEffect(() => {
    if (!inView) return;
    let cur = 0; const step = end / (duration / 16);
    const t = setInterval(() => { cur = Math.min(cur + step, end); setCount(Math.floor(cur)); if (cur >= end) clearInterval(t); }, 16);
    return () => clearInterval(t);
  }, [inView, end, duration]);
  return <span ref={ref}>{count.toLocaleString()}{suffix}</span>;
}

function Typewriter({ words }: { words: string[] }) {
  const [idx, setIdx] = useState(0);
  const [displayed, setDisplayed] = useState('');
  const [deleting, setDeleting] = useState(false);
  useEffect(() => {
    const word = words[idx];
    const timeout = setTimeout(() => {
      if (!deleting) {
        setDisplayed(word.slice(0, displayed.length + 1));
        if (displayed.length + 1 === word.length) setTimeout(() => setDeleting(true), 1800);
      } else {
        setDisplayed(word.slice(0, displayed.length - 1));
        if (displayed.length === 0) { setDeleting(false); setIdx((idx + 1) % words.length); }
      }
    }, deleting ? 50 : 80);
    return () => clearTimeout(timeout);
  }, [displayed, deleting, idx, words]);
  return (
    <span style={{ borderRight: '3px solid #f59e0b', paddingRight: 4, animation: 'blink 1s step-end infinite' }}>
      {displayed}
    </span>
  );
}

/* ─────────────────────────────────────────────
   DATA
───────────────────────────────────────────── */
const services = [
  { id: 1, title: 'NewsJunction', subtitle: 'Digital Media Network', icon: Newspaper, gradient: 'linear-gradient(135deg,#ef4444,#f97316)', accent: '#ef4444', shortDesc: 'Multi-lingual media powerhouse delivering news across India in 5 languages.', fullDesc: 'One Network. Many Voices. Delivering news in Kannada, Telugu, Tamil, Hindi, and English with 24+ years of journalistic integrity.', tag: 'Media', link: '/services' },
  { id: 2, title: 'Pearl Farms', subtitle: 'Premium Alternative Investment', icon: Sparkles, gradient: 'linear-gradient(135deg,#3b82f6,#06b6d4)', accent: '#3b82f6', shortDesc: 'Invest in a living asset — sustainable freshwater pearl farming with high returns.', fullDesc: 'Combine biological science with a lucrative, sustainable business. Passive income for professionals with complete farmer support.', tag: '★ Featured', link: '/pearl-farms', featured: true },
  { id: 3, title: 'Manikya Market', subtitle: 'Rapid Desi Online Bazar', icon: ShoppingBag, gradient: 'linear-gradient(135deg,#10b981,#059669)', accent: '#10b981', shortDesc: 'From the heart of villages to doorsteps worldwide — authentic Desi marketplace.', fullDesc: 'Story-driven commerce with shoppable content, empowering women entrepreneurs and self-help groups across India.', tag: 'Commerce', link: '/services' },
  { id: 4, title: 'Manikya Roots', subtitle: 'FMCG & Wellness', icon: Leaf, gradient: 'linear-gradient(135deg,#22c55e,#84cc16)', accent: '#22c55e', shortDesc: 'Purity in every grain, health in every sip. Amrutha Multi Millet Malt — 42 ingredients.', fullDesc: 'Wellness vertical bringing Ayurveda and traditional Indian nutrition to modern life through 42 handpicked ingredients.', tag: 'Wellness', link: '/services' },
  { id: 5, title: 'Manikya Heritage', subtitle: 'Mega Heritage Village', icon: Landmark, gradient: 'linear-gradient(135deg,#8b5cf6,#a855f7)', accent: '#8b5cf6', shortDesc: "Preserving Karnataka's architecture, art, and lifestyle for future generations.", fullDesc: 'A living museum with artisan workshops, heritage stays, Ayurvedic wellness zones, and immersive cultural performances.', tag: 'Culture', link: '/services' },
];

const stats = [
  { value: 24, suffix: '+', label: 'Years of Excellence', icon: Award },
  { value: 500, suffix: '+', label: 'Partners & Investors', icon: Users },
  { value: 5, suffix: '', label: 'Business Verticals', icon: Zap },
  { value: 42, suffix: '', label: 'Wellness Ingredients', icon: Leaf },
];

const testimonials = [
  { name: 'Rajesh Kumar', role: 'Pearl Farm Investor, Bengaluru', text: 'The returns from Manikya Pearl Farms exceeded all expectations. A truly unique living investment that I recommend to every professional.', rating: 5, initial: 'R' },
  { name: 'Priya Nair', role: 'Manikya Market Vendor, Mysuru', text: 'They gave my handloom business a global platform. My revenue tripled in just 6 months. The media exposure through NewsJunction was incredible.', rating: 5, initial: 'P' },
  { name: 'Dr. Suresh Rao', role: 'Wellness Partner, Mangaluru', text: 'Amrutha Multi Millet Malt is unlike anything on the market. My patients love the 42-ingredient formula and the results speak for themselves.', rating: 5, initial: 'S' },
];

/* ─────────────────────────────────────────────
   MAIN
───────────────────────────────────────────── */
export default function Home() {
  const [activeService, setActiveService] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState(0);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const statsSection = useInView();
  const servicesSection = useInView();
  const darkSection = useInView();
  const pearlSection = useInView();

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  }, []);

  useEffect(() => {
    const t = setInterval(() => setActiveTab(p => (p + 1) % testimonials.length), 4500);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={{ fontFamily: "'Palatino Linotype', Georgia, serif", overflowX: 'hidden' }}>
      <style>{`
        @keyframes floatOrb { 0% { transform:translate(-50%,-50%) scale(1); } 100% { transform:translate(-50%,-50%) scale(1.3) translate(20px,-30px); } }
        @keyframes gridMove { 0% { transform:translateY(0); } 100% { transform:translateY(60px); } }
        @keyframes shimmerGold { 0% { background-position:-200% center; } 100% { background-position:200% center; } }
        @keyframes blink { 50% { border-color:transparent; } }
        @keyframes slideUpFade { from { opacity:0; transform:translateY(50px); } to { opacity:1; transform:translateY(0); } }
        @keyframes slideLeftFade { from { opacity:0; transform:translateX(-60px); } to { opacity:1; transform:translateX(0); } }
        @keyframes rotateSlow { to { transform:rotate(360deg); } }
        @keyframes rotateSlowRev { to { transform:rotate(-360deg); } }
        @keyframes pulseGlow { 0%,100% { box-shadow:0 0 20px rgba(245,158,11,0.4); } 50% { box-shadow:0 0 50px rgba(245,158,11,0.9),0 0 90px rgba(245,158,11,0.3); } }
        @keyframes fadeSlideIn { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0); } }
        @keyframes morphBlob { 0% { border-radius:60% 40% 70% 30%/50% 60% 40% 70%; } 50% { border-radius:30% 70% 40% 60%/70% 30% 60% 40%; } 100% { border-radius:60% 40% 70% 30%/50% 60% 40% 70%; } }

        .hw1 { animation:slideLeftFade .9s cubic-bezier(.16,1,.3,1) .15s both; }
        .hw2 { animation:slideLeftFade .9s cubic-bezier(.16,1,.3,1) .32s both; }
        .hw3 { animation:slideUpFade  .9s cubic-bezier(.16,1,.3,1) .48s both; }
        .hw4 { animation:slideUpFade  .9s cubic-bezier(.16,1,.3,1) .64s both; }
        .hw5 { animation:slideUpFade  .9s cubic-bezier(.16,1,.3,1) .80s both; }

        .gold-shimmer {
          background:linear-gradient(90deg,#f59e0b,#fde68a,#f59e0b,#fbbf24,#f59e0b);
          background-size:300% auto;
          -webkit-background-clip:text; -webkit-text-fill-color:transparent;
          background-clip:text; animation:shimmerGold 4s linear infinite;
        }
        .glass { background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.12); backdrop-filter:blur(16px); }
        .glass-white { background:rgba(255,255,255,0.88); border:1px solid rgba(255,255,255,0.9); backdrop-filter:blur(20px); }

        .svc-card { transition:all .5s cubic-bezier(.16,1,.3,1); }
        .svc-card:hover { transform:translateY(-14px) scale(1.02); }

        .btn { position:relative; overflow:hidden; transition:all .3s ease; }
        .btn:hover { transform:translateY(-3px); }
        .btn::after { content:''; position:absolute; inset:0; background:linear-gradient(135deg,rgba(255,255,255,0.12),transparent); opacity:0; transition:opacity .3s; }
        .btn:hover::after { opacity:1; }

        .reveal { opacity:0; transform:translateY(36px); transition:all .75s cubic-bezier(.16,1,.3,1); }
        .reveal.on { opacity:1; transform:translateY(0); }

        .tline::before { content:''; display:inline-block; width:36px; height:3px; background:linear-gradient(90deg,#f59e0b,#fbbf24); margin-right:12px; vertical-align:middle; border-radius:2px; }
        .testi-anim { animation:fadeSlideIn .5s ease forwards; }

        .cursor-follow { pointer-events:none; position:absolute; width:420px; height:420px; border-radius:50%; background:radial-gradient(circle,rgba(245,158,11,0.055) 0%,transparent 70%); transform:translate(-50%,-50%); transition:left .08s,top .08s; }
      `}</style>

      {/* ══════ HERO ══════ */}
      <section
        className="relative min-h-screen flex items-center overflow-hidden"
        style={{ background: 'linear-gradient(135deg,#020817 0%,#0a1628 40%,#0f2048 70%,#1a3a6e 100%)' }}
        onMouseMove={handleMouseMove}
      >
        <StarField />
        <Aurora />
        <GridLines />
        <GlowOrbs />
        <div className="cursor-follow" style={{ left: mousePos.x, top: mousePos.y }} />

        {/* Morphing blob decorations */}
        {[
          { c: 'rgba(59,130,246,0.35)', x: '68%', y: '20%', s: 380, d: 0 },
          { c: 'rgba(245,158,11,0.2)', x: '12%', y: '58%', s: 260, d: 3 },
          { c: 'rgba(139,92,246,0.22)', x: '82%', y: '72%', s: 210, d: 6 },
        ].map((b, i) => (
          <div key={i} className="absolute pointer-events-none" style={{
            left: b.x, top: b.y, width: b.s, height: b.s,
            background: `radial-gradient(circle,${b.c},transparent 70%)`,
            filter: 'blur(50px)', transform: 'translate(-50%,-50%)',
            animation: `morphBlob ${12 + b.d}s ease-in-out ${b.d}s infinite`,
          }} />
        ))}

        {/* Rotating orbital rings */}
        <div className="absolute right-16 top-1/2 -translate-y-1/2 hidden xl:block" style={{ width: 560, height: 560 }}>
          {[560, 440, 330, 200].map((s, i) => (
            <div key={i} style={{
              position: 'absolute', width: s, height: s,
              top: '50%', left: '50%', transform: 'translate(-50%,-50%)',
              border: `1px solid rgba(255,255,255,${0.04 + i * 0.01})`,
              borderRadius: '50%',
              animation: `${i % 2 ? 'rotateSlowRev' : 'rotateSlow'} ${26 - i * 4}s linear infinite`,
            }}>
              {i === 0 && <div style={{ position: 'absolute', top: -6, left: '50%', transform: 'translateX(-50%)', width: 12, height: 12, borderRadius: '50%', background: '#f59e0b', boxShadow: '0 0 20px 8px rgba(245,158,11,0.55)', animation: 'pulseGlow 2s ease-in-out infinite' }} />}
              {i === 1 && <div style={{ position: 'absolute', bottom: -5, right: '22%', width: 8, height: 8, borderRadius: '50%', background: '#60a5fa', boxShadow: '0 0 14px 5px rgba(96,165,250,0.6)' }} />}
              {i === 2 && <div style={{ position: 'absolute', top: '22%', right: -5, width: 7, height: 7, borderRadius: '50%', background: '#34d399', boxShadow: '0 0 14px 5px rgba(52,211,153,0.6)' }} />}
            </div>
          ))}
          {/* Pearl orb center */}
          <div style={{
            position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)',
            width: 100, height: 100, borderRadius: '50%',
            background: 'radial-gradient(circle at 35% 35%,rgba(255,255,255,0.95),rgba(191,219,254,0.6),rgba(59,130,246,0.45))',
            boxShadow: '0 0 50px rgba(59,130,246,0.5), inset 0 0 20px rgba(255,255,255,0.2)',
            animation: 'pulseGlow 3s ease-in-out infinite',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Sparkles size={36} style={{ color: '#1e3a8a', opacity: 0.8 }} />
          </div>
        </div>

        {/* Content */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-36 z-10">
          <div style={{ maxWidth: '34rem' }}>
            {/* Badge */}
            <div className="hw1 inline-flex items-center gap-3 px-5 py-2.5 rounded-full mb-8"
              style={{ background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.35)' }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#fbbf24', boxShadow: '0 0 10px 5px rgba(251,191,36,0.5)', animation: 'pulseGlow 2s infinite', display: 'inline-block' }} />
              <span style={{ color: '#fde68a', fontSize: '0.68rem', letterSpacing: '0.25em', fontFamily: 'Georgia, serif', fontWeight: 700, textTransform: 'uppercase' }}>
                Established 2002 · Bengaluru, India
              </span>
            </div>

            <div className="hw2" style={{ color: '#93c5fd', fontSize: '1.05rem', marginBottom: 6, letterSpacing: '0.04em' }}>
              Manikya Services Private Limited
            </div>

            <h1 className="hw3 font-bold text-white" style={{ fontSize: 'clamp(3.8rem,8vw,6.2rem)', fontFamily: 'Georgia, serif', letterSpacing: '-0.02em', lineHeight: 1.05, marginBottom: 4 }}>
              Growing
            </h1>
            <h1 className="hw4 font-bold" style={{ fontSize: 'clamp(3.8rem,8vw,6.2rem)', fontFamily: 'Georgia, serif', letterSpacing: '-0.02em', lineHeight: 1.05, marginBottom: 28 }}>
              <span className="gold-shimmer">Together</span>
            </h1>

            <p className="hw5" style={{ color: '#bfdbfe', fontSize: '1.15rem', lineHeight: 1.75, marginBottom: 10 }}>
              Driving innovation across{' '}
              <span style={{ color: '#fde68a', fontWeight: 700 }}>
                <Typewriter words={['Media', 'Agriculture', 'Commerce', 'Wellness', 'Heritage']} />
              </span>
            </p>
            <p className="hw5" style={{ color: '#7dd3fc', fontSize: '0.95rem', lineHeight: 1.7, marginBottom: 36, maxWidth: '26rem' }}>
              Creating sustainable value through technology and tradition for a better India.
            </p>

            <div className="hw5" style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
              <Link to="/pearl-farms" className="btn inline-flex items-center gap-2 px-8 py-4 rounded-xl font-bold text-white"
                style={{ background: 'linear-gradient(135deg,#1d4ed8,#2563eb)', boxShadow: '0 8px 32px rgba(37,99,235,0.5)', letterSpacing: '0.04em' }}>
                <Sparkles size={18} /> Explore Pearl Farms <ArrowRight size={18} />
              </Link>
              <Link to="/contact" className="btn inline-flex items-center gap-2 px-8 py-4 rounded-xl font-bold"
                style={{ border: '1px solid rgba(255,255,255,0.25)', color: 'white' }}>
                <Play size={16} /> Get in Touch
              </Link>
            </div>

            {/* Trust pills */}
            <div className="hw5" style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginTop: 32 }}>
              {[['🏆', '24+ Years'], ['👥', '500+ Partners'], ['⚡', '5 Verticals'], ['🇮🇳', 'Made in India']].map(([icon, label]) => (
                <div key={label} className="glass px-4 py-2 rounded-full text-sm flex items-center gap-2" style={{ color: '#93c5fd' }}>
                  <span>{icon}</span><span>{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 100" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,60 C360,100 1080,20 1440,60 L1440,100 L0,100 Z" fill="#f8fafc" opacity="0.5" />
            <path d="M0,75 C480,110 960,40 1440,75 L1440,100 L0,100 Z" fill="#f8fafc" />
          </svg>
        </div>
      </section>

      {/* ══════ STATS ══════ */}
      <section className="py-20 bg-slate-50" ref={statsSection.ref}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((s, i) => {
              const Icon = s.icon;
              return (
                <div key={i} className={`glass-white rounded-2xl p-8 text-center reveal ${statsSection.inView ? 'on' : ''}`}
                  style={{ transitionDelay: `${i * 100}ms`, border: '1px solid #e2e8f0', boxShadow: '0 4px 20px rgba(0,0,0,0.05)', transition: `all .75s cubic-bezier(.16,1,.3,1) ${i * 100}ms` }}>
                  <div style={{ width: 48, height: 48, borderRadius: 14, background: 'linear-gradient(135deg,#1e40af,#1d4ed8)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                    <Icon size={22} color="white" />
                  </div>
                  <div style={{ fontSize: '2.8rem', fontWeight: 700, fontFamily: 'Georgia, serif', color: '#1e40af', lineHeight: 1 }}>
                    <Counter end={s.value} suffix={s.suffix} />
                  </div>
                  <div style={{ color: '#94a3b8', fontSize: '0.72rem', textTransform: 'uppercase', letterSpacing: '0.14em', marginTop: 8 }}>{s.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ══════ SERVICES ══════ */}
      <section className="py-28 relative overflow-hidden" style={{ background: 'linear-gradient(180deg,#f8fafc,#eff6ff)' }} ref={servicesSection.ref}>
        <div className="absolute top-0 right-0 w-96 h-96 rounded-full" style={{ background: 'radial-gradient(circle,rgba(59,130,246,0.06),transparent)', filter: 'blur(40px)' }} />
        <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full" style={{ background: 'radial-gradient(circle,rgba(245,158,11,0.06),transparent)', filter: 'blur(40px)' }} />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <p className="tline text-yellow-600 text-xs font-bold uppercase tracking-widest mb-5">Our Portfolio</p>
            <h2 style={{ fontSize: 'clamp(2.2rem,5vw,3.5rem)', fontFamily: 'Georgia, serif', fontWeight: 700, color: '#0f172a', letterSpacing: '-0.02em', marginBottom: 16 }}>
              Five Pillars of <span style={{ color: '#1e40af' }}>Sustainable Growth</span>
            </h2>
            <p style={{ color: '#64748b', maxWidth: '36rem', margin: '0 auto', lineHeight: 1.8 }}>
              Each venture is a carefully crafted ecosystem — interconnected, synergistic, and built to create lasting value for communities across India.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((s, i) => {
              const Icon = s.icon;
              const hov = activeService === s.id;
              return (
                <div key={s.id}
                  className={`svc-card rounded-2xl overflow-hidden cursor-pointer reveal ${servicesSection.inView ? 'on' : ''}`}
                  style={{
                    transitionDelay: `${i * 80}ms`,
                    background: 'white',
                    border: s.featured ? `2px solid ${s.accent}` : '1px solid #e2e8f0',
                    boxShadow: hov ? `0 32px 64px ${s.accent}28` : s.featured ? `0 4px 24px ${s.accent}20` : '0 2px 12px rgba(0,0,0,0.05)',
                    position: 'relative',
                  }}
                  onMouseEnter={() => setActiveService(s.id)}
                  onMouseLeave={() => setActiveService(null)}
                >
                  <div style={{ height: 4, background: s.gradient }} />
                  {/* hover glow overlay */}
                  <div style={{ position: 'absolute', inset: 0, background: s.gradient, opacity: hov ? 0.03 : 0, transition: 'opacity .4s', pointerEvents: 'none' }} />

                  <div style={{ padding: 32, position: 'relative' }}>
                    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24 }}>
                      <div style={{ width: 64, height: 64, borderRadius: 18, background: s.gradient, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `0 8px 24px ${s.accent}40`, transition: 'transform .35s', transform: hov ? 'scale(1.12) rotate(-6deg)' : 'scale(1)' }}>
                        <Icon size={28} color="white" />
                      </div>
                      <span style={{ padding: '4px 12px', borderRadius: 20, fontSize: '0.68rem', fontWeight: 700, color: 'white', background: s.gradient, letterSpacing: '0.1em', textTransform: 'uppercase' }}>{s.tag}</span>
                    </div>

                    <h3 style={{ fontSize: '1.5rem', fontWeight: 700, fontFamily: 'Georgia, serif', color: '#0f172a', marginBottom: 4 }}>{s.title}</h3>
                    <p style={{ fontSize: '0.72rem', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.12em', marginBottom: 14 }}>{s.subtitle}</p>
                    <p style={{ color: '#475569', lineHeight: 1.75, fontSize: '0.95rem', marginBottom: 20 }}>{s.shortDesc}</p>

                    <div style={{ overflow: 'hidden', maxHeight: hov ? 120 : 0, opacity: hov ? 1 : 0, transition: 'all .5s ease', marginBottom: hov ? 20 : 0 }}>
                      <p style={{ color: '#64748b', fontSize: '0.9rem', lineHeight: 1.7, paddingTop: 14, borderTop: '1px solid #f1f5f9' }}>{s.fullDesc}</p>
                    </div>

                    <Link to={s.link} style={{ display: 'inline-flex', alignItems: 'center', gap: hov ? 10 : 6, color: s.accent, fontWeight: 700, fontSize: '0.9rem', transition: 'gap .3s' }} onClick={e => e.stopPropagation()}>
                      Discover More <ChevronRight size={16} />
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ══════ DARK SECTION — Why Us + Testimonials ══════ */}
      <section className="py-28 relative overflow-hidden" style={{ background: 'linear-gradient(135deg,#020817,#0a1628,#0f2048)' }} ref={darkSection.ref}>
        <Aurora />
        <StarField />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
          <div className="grid lg:grid-cols-2 gap-20 items-center">
            {/* Left */}
            <div className={`reveal ${darkSection.inView ? 'on' : ''}`}>
              <p className="tline text-yellow-400 text-xs font-bold uppercase tracking-widest mb-6">Why Manikya</p>
              <h2 style={{ fontSize: 'clamp(2rem,4.5vw,3.2rem)', fontFamily: 'Georgia, serif', fontWeight: 700, color: 'white', lineHeight: 1.18, marginBottom: 24, letterSpacing: '-0.02em' }}>
                India's Most Trusted<br /><span className="gold-shimmer">Multi-Sector Enterprise</span>
              </h2>
              <p style={{ color: '#93c5fd', fontSize: '1.08rem', lineHeight: 1.8, marginBottom: 36 }}>
                We don't just run businesses — we build ecosystems. Each of our five verticals feeds and strengthens the others, creating a self-reinforcing circle of sustainable growth.
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {[
                  ['🔄', 'Circular synergy across all 5 business verticals'],
                  ['🏆', '24+ years of journalistic and entrepreneurial excellence'],
                  ['💡', 'Technology-driven approach with deep traditional roots'],
                  ['🌾', 'Direct empowerment of rural communities and artisans'],
                ].map(([icon, text], i) => (
                  <div key={i} className={`glass p-4 rounded-xl flex items-center gap-4 reveal ${darkSection.inView ? 'on' : ''}`} style={{ transitionDelay: `${200 + i * 100}ms` }}>
                    <span style={{ fontSize: '1.5rem', flexShrink: 0 }}>{icon}</span>
                    <span style={{ color: '#bfdbfe' }}>{text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Right — testimonials */}
            <div className={`reveal ${darkSection.inView ? 'on' : ''}`} style={{ transitionDelay: '200ms' }}>
              <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
                {testimonials.map((_, i) => (
                  <button key={i} onClick={() => setActiveTab(i)} style={{ height: 8, borderRadius: 4, border: 'none', cursor: 'pointer', transition: 'all .4s', width: activeTab === i ? 32 : 8, background: activeTab === i ? '#f59e0b' : 'rgba(255,255,255,0.2)' }} />
                ))}
              </div>
              {testimonials.map((t, i) => (
                <div key={i} style={{ display: i === activeTab ? 'block' : 'none' }} className="testi-anim">
                  <div className="glass rounded-2xl p-8">
                    <div style={{ display: 'flex', gap: 4, marginBottom: 20 }}>
                      {Array.from({ length: t.rating }).map((_, j) => <Star key={j} size={18} style={{ color: '#f59e0b', fill: '#f59e0b' }} />)}
                    </div>
                    <p style={{ fontSize: '1.08rem', color: '#bfdbfe', lineHeight: 1.75, marginBottom: 28, fontStyle: 'italic', fontFamily: 'Georgia, serif' }}>"{t.text}"</p>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                      <div style={{ width: 54, height: 54, borderRadius: '50%', background: 'linear-gradient(135deg,#f59e0b,#ef4444)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 700, fontSize: '1.3rem', fontFamily: 'Georgia, serif', boxShadow: '0 4px 18px rgba(245,158,11,0.4)', flexShrink: 0 }}>{t.initial}</div>
                      <div>
                        <div style={{ fontWeight: 700, color: 'white', fontFamily: 'Georgia, serif' }}>{t.name}</div>
                        <div style={{ color: '#60a5fa', fontSize: '0.85rem' }}>{t.role}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
                <button onClick={() => setActiveTab((activeTab - 1 + testimonials.length) % testimonials.length)} style={{ padding: '8px 18px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.15)', background: 'transparent', color: '#60a5fa', cursor: 'pointer', fontSize: '0.9rem' }}>← Prev</button>
                <button onClick={() => setActiveTab((activeTab + 1) % testimonials.length)} style={{ padding: '8px 18px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.15)', background: 'transparent', color: '#60a5fa', cursor: 'pointer', fontSize: '0.9rem' }}>Next →</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══════ PEARL FARMS FEATURE ══════ */}
      <section className="py-24 bg-white" ref={pearlSection.ref}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`rounded-3xl overflow-hidden reveal ${pearlSection.inView ? 'on' : ''}`}
            style={{ background: 'linear-gradient(135deg,#eff6ff,#dbeafe)', border: '1px solid #bfdbfe', boxShadow: '0 20px 60px rgba(59,130,246,0.1)' }}>
            <div className="grid lg:grid-cols-2">
              <div style={{ padding: '4rem' }}>
                <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '8px 16px', borderRadius: 20, background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.3)', marginBottom: 20 }}>
                  <Sparkles size={14} style={{ color: '#2563eb' }} />
                  <span style={{ color: '#1d4ed8', fontSize: '0.68rem', fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase' }}>Featured Investment Opportunity</span>
                </div>
                <h2 style={{ fontSize: '2.5rem', fontWeight: 700, fontFamily: 'Georgia, serif', color: '#0f172a', marginBottom: 14 }}>Manikya Pearl Farms</h2>
                <p style={{ color: '#475569', fontSize: '1.1rem', lineHeight: 1.8, marginBottom: 28 }}>
                  Invest in a <strong style={{ color: '#1e40af' }}>living asset</strong> — freshwater pearl farming combining biological science with sustainable business for genuine passive income.
                </p>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 28 }}>
                  {[['💎', 'Living Asset', 'Unique investment class'], ['💰', 'Passive Income', 'For working professionals'], ['🌿', 'Eco-Friendly', 'Sustainable model'], ['🤝', 'Expert Support', 'Full guidance']].map(([icon, label, desc]) => (
                    <div key={label} style={{ borderRadius: 14, padding: '14px 16px', background: 'rgba(255,255,255,0.65)', border: '1px solid rgba(59,130,246,0.12)' }}>
                      <div style={{ fontSize: '1.6rem', marginBottom: 4 }}>{icon}</div>
                      <div style={{ fontWeight: 700, color: '#0f172a', fontSize: '0.9rem', marginBottom: 2 }}>{label}</div>
                      <div style={{ color: '#64748b', fontSize: '0.8rem' }}>{desc}</div>
                    </div>
                  ))}
                </div>
                <Link to="/pearl-farms" className="btn inline-flex items-center gap-2 px-8 py-4 text-white font-bold rounded-xl"
                  style={{ background: 'linear-gradient(135deg,#1e3a8a,#1d4ed8)', boxShadow: '0 8px 32px rgba(29,78,216,0.4)' }}>
                  Explore Pearl Farms <ArrowRight size={18} />
                </Link>
              </div>

              <div style={{ padding: '4rem', background: 'linear-gradient(135deg,#1e3a8a,#1e40af)', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', color: 'white' }}>
                <div style={{ width: 110, height: 110, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%,rgba(255,255,255,0.95),rgba(191,219,254,0.6),rgba(59,130,246,0.45))', boxShadow: '0 0 50px rgba(191,219,254,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 20, animation: 'pulseGlow 3s ease-in-out infinite' }}>
                  <Sparkles size={44} style={{ color: '#1e3a8a', opacity: 0.85 }} />
                </div>
                <div className="gold-shimmer" style={{ fontSize: '5rem', fontWeight: 700, fontFamily: 'Georgia, serif', lineHeight: 1 }}>500+</div>
                <div style={{ color: '#93c5fd', marginBottom: 36 }}>Active Pearl Farm Investors</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12, width: '100%', maxWidth: 260 }}>
                  {['Freshwater pearl cultivation', 'Mandya district, Karnataka', 'High-yield sustainable returns', 'Professional investor support'].map((f, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, color: '#bfdbfe' }}>
                      <div style={{ width: 20, height: 20, borderRadius: '50%', background: 'rgba(245,158,11,0.2)', border: '1px solid rgba(245,158,11,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <span style={{ color: '#fbbf24', fontSize: '0.6rem' }}>✓</span>
                      </div>
                      <span style={{ fontSize: '0.9rem' }}>{f}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══════ CONTACT STRIP ══════ */}
      <section style={{ padding: '4rem 0', background: '#f1f5f9' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: Phone, label: 'Call Us', lines: ['+91 74116 42999', '+91 74117 42999'], color: '#1e40af' },
              { icon: Mail, label: 'Email Us', lines: ['manikyaservicespvtltd@gmail.com'], color: '#059669' },
              { icon: MapPin, label: 'Visit Us', lines: ['No.411, 3rd Floor, Old Airport Road', 'HAL Kodihalli, Bengaluru – 560008'], color: '#7c3aed' },
            ].map((c, i) => {
              const Icon = c.icon;
              return (
                <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 16, padding: 24, borderRadius: 18, background: 'white', border: '1px solid #e2e8f0', boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}>
                  <div style={{ width: 48, height: 48, borderRadius: 14, background: `${c.color}18`, border: `1px solid ${c.color}30`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Icon size={22} style={{ color: c.color }} />
                  </div>
                  <div>
                    <div style={{ color: '#94a3b8', fontSize: '0.68rem', textTransform: 'uppercase', letterSpacing: '0.15em', fontWeight: 700, marginBottom: 6 }}>{c.label}</div>
                    {c.lines.map((l, j) => <div key={j} style={{ color: '#334155', fontSize: '0.9rem', fontWeight: j === 0 ? 600 : 400 }}>{l}</div>)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ══════ CTA ══════ */}
      <section className="py-28 relative overflow-hidden text-white" style={{ background: 'linear-gradient(135deg,#1e40af,#1d4ed8,#2563eb)' }}>
        <Aurora />
        <StarField />
        <GlowOrbs />
        <div className="relative max-w-3xl mx-auto px-4 text-center z-10">
          <div style={{ width: 80, height: 80, borderRadius: 22, background: 'rgba(245,158,11,0.15)', border: '1px solid rgba(245,158,11,0.4)', boxShadow: '0 0 40px rgba(245,158,11,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 28px', animation: 'pulseGlow 3s ease-in-out infinite' }}>
            <TrendingUp size={36} style={{ color: '#fbbf24' }} />
          </div>
          <h2 style={{ fontSize: 'clamp(2.4rem,5vw,3.8rem)', fontFamily: 'Georgia, serif', fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.15, marginBottom: 20 }}>
            Ready to Partner<br />with <span className="gold-shimmer">Manikya?</span>
          </h2>
          <p style={{ fontSize: '1.15rem', color: '#bfdbfe', lineHeight: 1.8, marginBottom: 40 }}>
            Join hundreds of satisfied partners and investors growing their business with us. Together, we build a sustainable, prosperous India.
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14, justifyContent: 'center' }}>
            <Link to="/contact" className="btn inline-flex items-center gap-2 px-10 py-4 bg-white font-bold rounded-xl"
              style={{ color: '#1e40af', boxShadow: '0 8px 32px rgba(0,0,0,0.2)' }}>
              Contact Us Today <ArrowRight size={20} />
            </Link>
            <Link to="/services" className="btn inline-flex items-center gap-2 px-10 py-4 font-bold rounded-xl"
              style={{ border: '1px solid rgba(255,255,255,0.3)', color: 'white' }}>
              View All Services
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
