import { useState } from 'react';
import { X } from 'lucide-react';

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const galleryImages = [
    {
      id: 1,
      title: 'Pearl Farming Operation',
      category: 'Pearl Farms',
      description: 'Our state-of-the-art pearl farming facility',
    },
    {
      id: 2,
      title: 'Freshwater Pearl Oysters',
      category: 'Pearl Farms',
      description: 'Healthy oysters in cultivation cages',
    },
    {
      id: 3,
      title: 'Harvested Pearls',
      category: 'Products',
      description: 'Beautiful freshwater pearls from our farms',
    },
    {
      id: 4,
      title: 'Farmer Training Program',
      category: 'Community',
      description: 'Training session with partner farmers',
    },
    {
      id: 5,
      title: 'Quality Inspection',
      category: 'Pearl Farms',
      description: 'Expert quality control and grading',
    },
    {
      id: 6,
      title: 'NewsJunction Platform',
      category: 'Digital Media',
      description: 'Our digital news distribution network',
    },
    {
      id: 7,
      title: 'Manikya Market',
      category: 'E-commerce',
      description: 'E-commerce platform showcase',
    },
    {
      id: 8,
      title: 'Wellness Products',
      category: 'Products',
      description: 'Manikya Roots product line',
    },
    {
      id: 9,
      title: 'Cultural Heritage',
      category: 'Heritage',
      description: 'Traditional crafts and artisan work',
    },
  ];

  const categories = ['All', ...Array.from(new Set(galleryImages.map(img => img.category)))];
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredImages = activeCategory === 'All'
    ? galleryImages
    : galleryImages.filter(img => img.category === activeCategory);

  return (
    <div>
      <section className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Gallery</h1>
          <p className="text-xl text-blue-100 max-w-3xl">
            Explore our work through images showcasing our pearl farms, products, and community initiatives.
          </p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-4 mb-12 justify-center">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-6 py-2 rounded-full font-medium transition-colors ${
                  activeCategory === category
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredImages.map((image, idx) => (
              <div
                key={image.id}
                className="group relative overflow-hidden rounded-lg shadow-md hover:shadow-xl transition-shadow cursor-pointer"
                onClick={() => setSelectedImage(idx)}
              >
                <div className="aspect-video bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center">
                  <div className="text-white text-center p-6">
                    <div className="text-6xl mb-4">🖼️</div>
                    <p className="text-sm opacity-75">Image placeholder</p>
                  </div>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end">
                  <div className="p-4 text-white w-full">
                    <div className="text-xs font-semibold mb-1 opacity-90">{image.category}</div>
                    <h3 className="font-bold text-lg">{image.title}</h3>
                    <p className="text-sm opacity-90">{image.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredImages.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-600 text-lg">No images found in this category.</p>
            </div>
          )}
        </div>
      </section>

      {selectedImage !== null && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button
            className="absolute top-4 right-4 text-white hover:text-gray-300"
            onClick={() => setSelectedImage(null)}
          >
            <X size={32} />
          </button>
          <div className="max-w-5xl w-full">
            <div className="bg-gradient-to-br from-blue-400 to-purple-500 rounded-lg aspect-video flex items-center justify-center">
              <div className="text-white text-center p-12">
                <div className="text-8xl mb-6">🖼️</div>
                <h3 className="text-2xl font-bold mb-2">{filteredImages[selectedImage].title}</h3>
                <p className="text-lg opacity-90">{filteredImages[selectedImage].description}</p>
                <p className="text-sm mt-4 opacity-75">
                  Image {selectedImage + 1} of {filteredImages.length}
                </p>
              </div>
            </div>
            <div className="mt-4 text-white text-center">
              <p className="text-sm opacity-75">Click anywhere to close</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
