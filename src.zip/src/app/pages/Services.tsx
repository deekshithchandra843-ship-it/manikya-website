import { Link } from 'react-router';
import { Newspaper, Sparkles, ShoppingBag, Leaf, Landmark, ArrowRight } from 'lucide-react';

export default function Services() {
  const services = [
    {
      id: 1,
      title: 'NewsJunction - Digital Media Network',
      tagline: 'One Network. Many Voices.',
      icon: Newspaper,
      description: 'NewsJunction has evolved from a regional portal into a National Multi-Lingual Media Powerhouse. By diversifying into specific languages and specialized niche channels, we are building a "Media Conglomerate" that mirrors the diversity of India.',
      features: [
        'Multi-lingual news in Kannada, Telugu, Tamil, Hindi, and English',
        'Hyper-local stories from all 31 districts of Karnataka',
        'Real-time content delivery across platforms',
        'Entertainment verticals including Music Junction and Comedy Junction',
        'Shoppable content integrated with Manikya Market',
      ],
      color: 'from-red-500 to-red-600',
    },
    {
      id: 2,
      title: 'Manikya Pearl Farms',
      tagline: 'Where Nature Meets High-Yield Financial Growth',
      icon: Sparkles,
      description: 'A premium alternative investment opportunity combining sustainable freshwater pearl farming with lucrative returns. We connect cane-growing farmers with investors, transforming conventional agricultural land into a high-value farming business ecosystem.',
      features: [
        'Passive income for busy professionals (IT, Healthcare, Legal)',
        'High-yield ROI through biological science',
        'Complete technical and operational guidance for farmers',
        'End-to-end support from pond preparation to pearl sales',
        '100% buyback assurance with market access',
        'Farmer engagement with sustainable income model',
      ],
      color: 'from-blue-500 to-blue-600',
      featured: true,
      link: '/pearl-farms',
    },
    {
      id: 3,
      title: 'Manikya Market - Rapid Desi Online Bazar',
      tagline: 'From the Heart of Villages to Doorsteps Worldwide',
      icon: ShoppingBag,
      description: 'Not just an e-commerce site, Manikya Market is a tech-enabled marketplace that bridges the gap between traditional craftsmanship and global consumers. We focus on authenticity, purity, and speed, taking local products to a global stage.',
      features: [
        'Rapid delivery with "rurban" logistics network',
        'Purely Desi products - 100% Indian origin',
        'Story-driven commerce with "Meet the Maker" content',
        'Shoppable content integrated with NewsJunction',
        'Platform for women entrepreneurs and self-help groups',
        'Zero technical burden for rural producers',
      ],
      color: 'from-green-500 to-green-600',
    },
    {
      id: 4,
      title: 'Manikya Roots - FMCG & Wellness',
      tagline: 'Purity in Every Grain, Health in Every Sip',
      icon: Leaf,
      description: 'The wellness vertical of Manikya Groups, bringing back the forgotten wisdom of Ayurveda and traditional Indian nutrition, adapted for modern, fast-paced 21st-century lifestyles.',
      features: [
        'Amrutha Multi Millet Malt - 42 handpicked ingredients',
        'Ancient millets, Ayurvedic herbs, nuts & seeds',
        'No refined sugar - diabetic-friendly formulation',
        'Clean label products (no chemicals, no preservatives)',
        'Cold-pressed oils, stone-ground spices, millet-based snacks',
        'Chemical-free personal care and hair growth oils',
      ],
      color: 'from-emerald-500 to-emerald-600',
    },
    {
      id: 5,
      title: 'Manikya Heritage - Mega Heritage Village',
      tagline: 'Preserving the Past, Inspiring the Future',
      icon: Landmark,
      description: 'The cultural soul of Manikya Groups - a visionary project designed as a "Living Museum" and immersive retreat. The Mega Heritage Village preserves Karnataka\'s architecture, art, and lifestyle while creating sustainable futures for local artisans.',
      features: [
        'Authentic reconstructed traditional homes (Chowkimane, Gutthu Mane)',
        'Cultural immersive zones for folk arts (Yakshagana, Dollu Kunitha)',
        'Ayurvedic Grama with herb gardens and wellness centers',
        'Artisan Street with live workshops for weavers and potters',
        'Heritage stay cottages for digital detox experiences',
        'Desi food court with millet-based meals and forgotten recipes',
      ],
      color: 'from-purple-500 to-purple-600',
    },
  ];

  return (
    <div>
      <section className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h1>
          <p className="text-xl text-blue-100 max-w-3xl">
            Comprehensive solutions across multiple sectors, delivering value through innovation and excellence.
          </p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-12">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <div
                  key={service.id}
                  className={`grid grid-cols-1 lg:grid-cols-2 gap-8 items-center ${
                    index % 2 === 1 ? 'lg:grid-flow-dense' : ''
                  }`}
                >
                  <div className={index % 2 === 1 ? 'lg:col-start-2' : ''}>
                    <div className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-lg flex items-center justify-center mb-4`}>
                      <Icon className="text-white" size={32} />
                    </div>
                    {service.featured && (
                      <div className="inline-block px-3 py-1 bg-blue-100 text-blue-600 text-sm font-semibold rounded-full mb-3">
                        Featured Service
                      </div>
                    )}
                    <h2 className="text-3xl font-bold text-gray-900 mb-2">{service.title}</h2>
                    <p className="text-lg italic text-gray-600 mb-4">{service.tagline}</p>
                    <p className="text-lg text-gray-700 mb-6">{service.description}</p>
                    <ul className="space-y-3 mb-6">
                      {service.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start">
                          <svg
                            className="w-6 h-6 text-blue-600 mr-2 flex-shrink-0"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M5 13l4 4L19 7"
                            />
                          </svg>
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    {service.link ? (
                      <Link
                        to={service.link}
                        className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                      >
                        Learn More
                        <ArrowRight className="ml-2" size={20} />
                      </Link>
                    ) : (
                      <Link
                        to="/contact"
                        className="inline-flex items-center px-6 py-3 bg-gray-900 text-white rounded-lg font-semibold hover:bg-gray-800 transition-colors"
                      >
                        Get Started
                        <ArrowRight className="ml-2" size={20} />
                      </Link>
                    )}
                  </div>
                  <div className={index % 2 === 1 ? 'lg:col-start-1 lg:row-start-1' : ''}>
                    <div className={`bg-gradient-to-br ${service.color} rounded-lg p-12 text-white`}>
                      <Icon size={80} className="opacity-20 mb-6" />
                      <h3 className="text-2xl font-bold mb-4">Key Benefits</h3>
                      <div className="space-y-4">
                        <div className="bg-white bg-opacity-20 rounded-lg p-4">
                          <div className="font-semibold mb-1">Proven Track Record</div>
                          <div className="text-sm opacity-90">Years of successful operations</div>
                        </div>
                        <div className="bg-white bg-opacity-20 rounded-lg p-4">
                          <div className="font-semibold mb-1">Expert Team</div>
                          <div className="text-sm opacity-90">Industry professionals at your service</div>
                        </div>
                        <div className="bg-white bg-opacity-20 rounded-lg p-4">
                          <div className="font-semibold mb-1">Customer Support</div>
                          <div className="text-sm opacity-90">24/7 assistance and guidance</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Ready to Explore Our Services?
          </h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Contact us today to learn how Manikya Services can help you achieve your business goals.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center px-8 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
          >
            Contact Us
            <ArrowRight className="ml-2" size={20} />
          </Link>
        </div>
      </section>
    </div>
  );
}
