import { Target, Eye, Award, Heart } from 'lucide-react';

export default function About() {
  return (
    <div>
      <section className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">About Manikya Services</h1>
          <p className="text-2xl italic mb-4">Growing Together</p>
          <p className="text-xl text-blue-100 max-w-3xl">
            A pioneering multi-sector enterprise dedicated to creating sustainable value through innovation, technology, and traditional excellence.
          </p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Who We Are</h2>
              <p className="text-lg text-gray-700 mb-4">
                <strong>Manikya Services Private Limited</strong> is a dynamic multi-sector enterprise built on the philosophy of <strong>innovation</strong> and <strong>sustainability</strong>. We are committed to addressing the challenges across diverse industries by leveraging cutting-edge technology and traditional business excellence.
              </p>
              <p className="text-lg text-gray-700 mb-4">
                Our core philosophy centers on creating value through <strong>innovation</strong>, delivering solutions with <strong>integrity</strong>, and implementing <strong>sustainable practices</strong> that ensure mutual growth for all stakeholders.
              </p>
              <p className="text-lg text-gray-700 mb-4">
                From sustainable pearl farming and digital media networks to e-commerce platforms, wellness products, and cultural preservation - we operate across five major verticals, each designed to empower communities and drive economic transformation.
              </p>
              <p className="text-lg text-gray-700">
                With <strong>NewsJunction</strong> reaching millions across India, <strong>Manikya Pearl Farms</strong> transforming agricultural livelihoods, <strong>Manikya Market</strong> connecting rural artisans to global markets, <strong>Manikya Roots</strong> promoting traditional wellness, and <strong>Manikya Heritage</strong> preserving Karnataka's rich cultural legacy - we are truly growing together.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div className="bg-blue-50 p-6 rounded-lg">
                <div className="text-4xl font-bold text-blue-600 mb-2">5</div>
                <div className="text-gray-700">Business Verticals</div>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg">
                <div className="text-4xl font-bold text-blue-600 mb-2">24+</div>
                <div className="text-gray-700">Years in Media</div>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg">
                <div className="text-4xl font-bold text-blue-600 mb-2">100+</div>
                <div className="text-gray-700">Partner Farmers</div>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg">
                <div className="text-4xl font-bold text-blue-600 mb-2">Growing</div>
                <div className="text-gray-700">Together</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                <Eye className="text-blue-600" size={32} />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Vision</h2>
              <p className="text-lg text-gray-700">
                To create transformative solutions through innovation, digital transformation, and sustainable growth. We envision becoming a national leader in multi-sector entrepreneurship, where traditional wisdom meets modern technology to create lasting value for communities, investors, and the environment.
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                <Target className="text-blue-600" size={32} />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h2>
              <p className="text-lg text-gray-700">
                To pioneer excellence across media, agriculture, commerce, wellness, and heritage preservation. We empower farmers with sustainable income models, connect artisans to global markets, deliver trustworthy news and information, promote holistic wellness, and preserve cultural legacies - all through transparent, ethical, and innovative business practices.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">Our Core Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="text-blue-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Excellence</h3>
              <p className="text-gray-600">
                Committed to delivering superior quality in every endeavor.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="text-blue-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Integrity</h3>
              <p className="text-gray-600">
                Building trust through transparency and ethical practices.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="text-blue-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Innovation</h3>
              <p className="text-gray-600">
                Embracing new ideas to solve age-old challenges.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Eye className="text-blue-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Sustainability</h3>
              <p className="text-gray-600">
                Creating long-term value for people and planet.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
