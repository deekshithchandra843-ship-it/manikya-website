export default function Logo({ className = "w-16 h-16 object-contain" }: { className?: string }) {
  return (
    <img
      src="/src/imports/image-3.png"
      alt="Manikya Services Pvt Ltd"
      className={className}
      style={{ imageRendering: 'crisp-edges' }}
    />
  );
}
