-- ============================================================
-- Manikya Services — PostgreSQL Schema
-- Run this file once: psql -U postgres -d manikya_db -f schema.sql
-- ============================================================

-- Enable pgcrypto for UUID generation
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ────────────────────────────────────────────────
-- 1. ADMIN USERS
-- ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS admin_users (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  email        TEXT        NOT NULL UNIQUE,
  password_hash TEXT       NOT NULL,
  name         TEXT        NOT NULL DEFAULT 'Admin',
  is_active    BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_login   TIMESTAMPTZ
);

-- ────────────────────────────────────────────────
-- 2. USERS (public — OTP / magic-link auth)
-- ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  email        TEXT        UNIQUE,
  phone        TEXT        UNIQUE,
  name         TEXT,
  is_verified  BOOLEAN     NOT NULL DEFAULT FALSE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_login   TIMESTAMPTZ,
  CONSTRAINT chk_contact CHECK (email IS NOT NULL OR phone IS NOT NULL)
);

-- ────────────────────────────────────────────────
-- 3. OTP TOKENS (email & phone auth)
-- ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS otp_tokens (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  identifier   TEXT        NOT NULL,          -- email or phone
  method       TEXT        NOT NULL CHECK (method IN ('email', 'phone')),
  type         TEXT        NOT NULL CHECK (type IN ('otp', 'magic_link')),
  token        TEXT        NOT NULL,           -- 6-digit OTP or random magic token
  expires_at   TIMESTAMPTZ NOT NULL,
  used         BOOLEAN     NOT NULL DEFAULT FALSE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_otp_identifier ON otp_tokens (identifier, used, expires_at);

-- ────────────────────────────────────────────────
-- 4. LOGIN ANALYTICS
-- ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS login_attempts (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  method       TEXT        NOT NULL CHECK (method IN ('email', 'phone')),
  type         TEXT        NOT NULL CHECK (type IN ('otp', 'magic_link')),
  identifier   TEXT        NOT NULL,
  status       TEXT        NOT NULL CHECK (status IN ('success', 'failed', 'pending')),
  ip_address   TEXT,
  user_agent   TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_login_created ON login_attempts (created_at DESC);

-- ────────────────────────────────────────────────
-- 5. SERVICES
-- ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS services (
  id           SERIAL      PRIMARY KEY,
  title        TEXT        NOT NULL,
  description  TEXT        NOT NULL,
  icon         TEXT,                           -- icon name / emoji
  is_active    BOOLEAN     NOT NULL DEFAULT TRUE,
  display_order INT        NOT NULL DEFAULT 0,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ────────────────────────────────────────────────
-- 6. CONTACT LEADS
-- ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contact_leads (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  name         TEXT        NOT NULL,
  email        TEXT,
  phone        TEXT,
  interest     TEXT,
  message      TEXT        NOT NULL,
  status       TEXT        NOT NULL DEFAULT 'new'
                           CHECK (status IN ('new', 'contacted', 'closed')),
  ip_address   TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_lead_contact CHECK (email IS NOT NULL OR phone IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS idx_leads_created  ON contact_leads (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_leads_status   ON contact_leads (status);

-- ────────────────────────────────────────────────
-- 7. GALLERY
-- ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS gallery_items (
  id           SERIAL      PRIMARY KEY,
  title        TEXT        NOT NULL,
  category     TEXT        NOT NULL DEFAULT 'General',
  image_url    TEXT,                           -- URL after uploading to object storage
  image_data   TEXT,                           -- base64 fallback (for small images)
  color        TEXT        NOT NULL DEFAULT '#8B6914',
  is_active    BOOLEAN     NOT NULL DEFAULT TRUE,
  display_order INT        NOT NULL DEFAULT 0,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ────────────────────────────────────────────────
-- 8. PRODUCTS
-- ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS products (
  id           SERIAL      PRIMARY KEY,
  name         TEXT        NOT NULL,
  description  TEXT,
  category     TEXT        NOT NULL DEFAULT 'General',
  price        NUMERIC(10,2),
  image_url    TEXT,
  is_available BOOLEAN     NOT NULL DEFAULT TRUE,
  display_order INT        NOT NULL DEFAULT 0,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ────────────────────────────────────────────────
-- 9. AUTO-UPDATE updated_at TRIGGER
-- ────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
DECLARE
  tbl TEXT;
BEGIN
  FOREACH tbl IN ARRAY ARRAY['services','gallery_items','products'] LOOP
    EXECUTE format(
      'DROP TRIGGER IF EXISTS trg_updated_%I ON %I;
       CREATE TRIGGER trg_updated_%I
       BEFORE UPDATE ON %I
       FOR EACH ROW EXECUTE FUNCTION set_updated_at();',
      tbl, tbl, tbl, tbl
    );
  END LOOP;
END $$;

-- ────────────────────────────────────────────────
-- 10. SEED DATA
-- ────────────────────────────────────────────────
INSERT INTO services (title, description, icon, display_order) VALUES
  ('NewsJunction',       'Digital Media Network — 24+ years of journalism',    '📺', 1),
  ('Manikya Pearl Farms','Sustainable freshwater pearl farming in Karnataka',   '🦪', 2),
  ('Manikya Market',     'Rapid Desi Online Bazar — Local to Global',          '🛒', 3),
  ('Manikya Roots',      'FMCG & Wellness — Amrutha Multi Millet Malt',        '🌿', 4),
  ('Manikya Heritage',   'Mega Heritage Village — Preserving Karnataka culture','🏛️', 5),
  ('Manikya Properties', 'Real estate & property loans across Karnataka',       '🏠', 6),
  ('Manikya Money',      'Financial services, loans and insurance',             '💰', 7)
ON CONFLICT DO NOTHING;

INSERT INTO gallery_items (title, category, color, display_order) VALUES
  ('Pearl Harvest',       'Pearl Farms', '#8B6914', 1),
  ('Heritage Village',    'Heritage',   '#5C3D2E', 2),
  ('Newsroom Studio',     'Media',      '#1a3a5c', 3),
  ('Millet Products',     'Products',   '#4a7c59', 4),
  ('Market Artisans',     'Market',     '#7c4a3e', 5),
  ('Cultural Festival',   'Heritage',   '#8B4513', 6)
ON CONFLICT DO NOTHING;

INSERT INTO products (name, description, category, price, display_order) VALUES
  ('Amrutha Multi Millet Malt', 'Traditional multi-millet health drink powder, 500g', 'Wellness', 349.00, 1),
  ('Pearl Jewellery Set',       'Handcrafted freshwater pearl necklace + earrings',   'Jewellery', 4999.00, 2),
  ('Organic Ragi Flour',        'Stone-ground organic finger millet flour, 1kg',      'FMCG', 149.00, 3),
  ('Heritage Craft Kit',        'Traditional Karnataka craft activity kit',           'Heritage', 799.00, 4)
ON CONFLICT DO NOTHING;
